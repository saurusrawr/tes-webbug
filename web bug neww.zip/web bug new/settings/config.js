module.exports = {
  Token: "8470455682:AAEOGr78fD_MjDK2pG9-WdSovEubl7w0iqA",
  owner: "6918729990",
};